import os
import logging
from flask import Flask, request, jsonify, session
from flask_cors import CORS
import requests

# Configure logging
logging.basicConfig(level=logging.INFO)

app = Flask(__name__)
CORS(app)
app.secret_key = os.urandom(24)  # Secret key for session management

# ✅ Hardcoded API Key (Replace with your actual API key)
serper_api_key = "60dc9e3093ecc5f971ff0ba7aeffcd44908e4ced"

if not serper_api_key:
    logging.warning("⚠️ Warning: SERPER_API_KEY is missing. Web search may not work.")

def search_news(query):
    """Fetch the latest news using Serper API."""
    if not serper_api_key:
        return "Web search is unavailable due to missing API key."
    
    url = "https://google.serper.dev/news"
    headers = {
        "X-API-KEY": serper_api_key,  # ✅ Correct API Key Placement
        "Content-Type": "application/json"
    }
    payload = {"q": query, "num": 3}

    response = requests.post(url, json=payload, headers=headers)
    
    # ✅ Debugging: Print response details
    print(f"Serper API Response: {response.status_code} - {response.text}")

    if response.status_code == 200:
        results = response.json().get("news", [])
        return "\n".join([f"{r['title']}: {r['link']}" for r in results]) if results else "No relevant news found."
    
    return f"Error fetching news: {response.status_code} - {response.text}"

@app.route('/')
def home():
    return jsonify({"message": "News Verification Chatbot API is running!"})

@app.route('/chat', methods=['POST'])
def chat():
    data = request.json
    question = data.get('question')
    
    if not question:
        return jsonify({"error": "Missing question"}), 400

    session.setdefault("chat_history", [])
    history_text = "\n".join([msg["content"] for msg in session["chat_history"]])

    search_results = search_news(question)
    response = f"User: {question}\nNews Update: {search_results}"
    
    session["chat_history"].append({"role": "user", "content": question})
    session["chat_history"].append({"role": "assistant", "content": search_results})

    return jsonify({"response": response})

if __name__ == '__main__':
    debug_mode = os.getenv("FLASK_DEBUG", "false").lower() == "true"
    app.run(debug=debug_mode, host="127.0.0.1", port=8000)
