import React from "react";
import "../styles/global.css";

const articles = [
  { title: "AI Revolution: Impact on Jobs", credibility: 85 },
  { title: "Climate Change: Fact or Fiction?", credibility: 92 },
  { title: "Electric Vehicles: Are They Sustainable?", credibility: 78 },
  { title: "Social Media's Role in Fake News", credibility: 88 },
  { title: "SpaceX's Mars Mission: Feasible or Hype?", credibility: 80 },
  { title: "Cryptocurrency: Future of Money?", credibility: 75 },
  { title: "COVID-19 Vaccine: Myths vs Facts", credibility: 94 },
  { title: "5G Technology: Health Risks?", credibility: 82 },
  { title: "Deepfake Technology: Threat or Innovation?", credibility: 90 },
  { title: "The Rise of Quantum Computing", credibility: 87 },
];

const Community = () => {
  return (
    <div className="community-container">
        <br/>

        <br/>
      <h2 className="community-title">APPROVED ARTICLES</h2>
      <p className="community-subtitle">Explore fact-checked articles with credibility scores</p>

      <div className="articles-grid">
        {articles.map((article, index) => (
          <div key={index} className="article-card">
            <h3 className="article-title">{article.title}</h3>
            <p className="credibility-score">Credibility Score: {article.credibility}%</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Community;
