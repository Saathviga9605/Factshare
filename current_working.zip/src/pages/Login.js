import React, { useState } from "react";
import { motion } from "framer-motion";
import "../styles/global.css";
import Register from "./Register"; // Ensure Register is correctly imported

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showRegister, setShowRegister] = useState(false); // ✅ State for toggling Register component

  const handleLogin = (e) => {
    e.preventDefault();
    console.log("Logging in with:", email, password);
  };

  return (
    <>
      {showRegister ? (
        <Register />
      ) : (
        <div className="login-container">
          {/* Background with Black Overlay */}
          <div className="login-background">
            <div className="login-overlay"></div>
          </div>

          {/* Animated Login Card */}
          <motion.div
            className="login-card"
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="login-title">Join the Movement</h2>
            <p className="login-subtitle">
              Stand against misinformation. Verify before you believe.
            </p>

            {/* Login Form */}
            <form onSubmit={handleLogin}>
              <motion.input
                type="email"
                placeholder="Email"
                className="login-input"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                whileFocus={{ scale: 1.05 }}
              />
              <motion.input
                type="password"
                placeholder="Password"
                className="login-input"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                whileFocus={{ scale: 1.05 }}
              />
              <motion.button
                type="submit"
                className="login-btn"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                Sign In
              </motion.button>
            </form>

            {/* Switch to Register */}
            <p className="login-footer">
              Don't have an account?{" "}
              <span
                className="register-link"
                onClick={() => setShowRegister(true)} // ✅ Change state to show Register
              >
                Join Us
              </span>
            </p>
          </motion.div>
        </div>
      )}
    </>
  );
};

export default Login;
