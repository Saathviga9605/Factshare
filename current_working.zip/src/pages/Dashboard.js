import React from "react";
import Graphs from "../components/Graphs";
import VersionHistory from "../components/VersionHistory";
import CredibilityScore from "../components/CredibilityScore";

const Dashboard = () => {
  return (
    <div className="container">
      <h2>Verification Dashboard</h2>
      <Graphs />
      <CredibilityScore />
      <VersionHistory />
    </div>
  );
};

export default Dashboard;
