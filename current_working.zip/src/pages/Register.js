import React, { useState } from "react";
import { motion } from "framer-motion";
import "../styles/global.css";
import Login from "./Login"; 

const Register = ({ switchToLogin }) => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showLogin, setShowLogin] = useState(false);

  const handleRegister = (e) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      alert("Passwords do not match!");
      return;
    }
    console.log("Registering:", name, email, password);
  };

  return (
    <>
      {showLogin ? (
        <Login />
      ) : (
        <div className="login-container">
          {/* Background with Black Overlay */}
    
          <div className="login-background">
            <div className="login-overlay"></div>
          </div>

          {/* Animated Register Card */}
          <motion.div 
            className="login-card"
            initial={{ opacity: 0, y: -30 }} 
            animate={{ opacity: 1, y: 0 }} 
            transition={{ duration: 0.8 }}
          >
            <h2 className="login-title">Create an Account</h2>
            <p className="login-subtitle">
              Join the fight against misinformation. Register now!
            </p>

            {/* Register Form */}
            <form onSubmit={handleRegister}>
              <motion.input 
                type="text" 
                placeholder="Full Name" 
                className="login-input" 
                value={name} 
                onChange={(e) => setName(e.target.value)}
                whileFocus={{ scale: 1.05 }}
              />
              <motion.input 
                type="email" 
                placeholder="Email" 
                className="login-input" 
                value={email} 
                onChange={(e) => setEmail(e.target.value)}
                whileFocus={{ scale: 1.05 }}
              />
              <motion.input 
                type="password" 
                placeholder="Password" 
                className="login-input" 
                value={password} 
                onChange={(e) => setPassword(e.target.value)}
                whileFocus={{ scale: 1.05 }}
              />
              <motion.input 
                type="password" 
                placeholder="Confirm Password" 
                className="login-input" 
                value={confirmPassword} 
                onChange={(e) => setConfirmPassword(e.target.value)}
                whileFocus={{ scale: 1.05 }}
              />
              <motion.button 
                type="submit" 
                className="login-btn"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                Register
              </motion.button>
            </form>

            {/* Switch to Login */}
            <p className="login-footer">
              Already have an account? 
              <span
                className="register-link"
                onClick={() => setShowLogin(true)} 
              >
                Sign In
              </span>
            </p>
          </motion.div>
        </div>
      )}
    </>
  ); // ✅ Closing properly

};

export default Register;
