import React, { useState } from "react";
import axios from "axios";
import "../styles/global.css"; // ✅ Import Chatbot Styles

function Chatbot() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [isOpen, setIsOpen] = useState(false); // ✅ Handle Chatbot Open/Close

  // Function to send a message
  const sendMessage = async () => {
    if (!input.trim()) return; // Prevent sending empty messages

    const userMessage = { role: "user", content: input };

    // Update frontend chat history
    setMessages([...messages, userMessage]);
    setInput(""); // Clear input field after sending

    try {
      const response = await axios.post("http://127.0.0.1:8000/chat", {
        question: input,
      });

      const botMessage = { role: "assistant", content: response.data.response };
      setMessages((prevMessages) => [...prevMessages, botMessage]);
    } catch (error) {
      console.error("Error:", error);
      alert("Failed to get a response.");
    }
  };

  return (
    <div className={`chatbot-container ${isOpen ? "open" : ""}`}>
      <button className="chat-toggle" onClick={() => setIsOpen(!isOpen)}>
        💬
      </button>

      {isOpen && (
        <div className="chat-box">
          <h2>📰 FactBot - Your News Assistant</h2>
          <div className="chat-messages">
            {messages.map((msg, index) => (
              <div key={index} className={msg.role === "user" ? "user-msg" : "bot-msg"}>
                <strong>{msg.role === "user" ? "You" : "FactBot"}:</strong> {msg.content}
              </div>
            ))}
          </div>
          <div className="chat-input">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask me anything, and I'll fact-check it for you!"
            />
            <button onClick={sendMessage}>Send</button>
          </div>
        </div>
      )}
    </div>
  );
}

export default Chatbot;
