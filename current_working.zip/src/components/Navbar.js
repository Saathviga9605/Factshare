import React from "react";
import "../styles/global.css";

const Navbar = ({ setPage, darkMode, toggleDarkMode }) => {
  return (
    <nav className="glass navbar">
      {/* Website Name & Motto */}
      <div className="logo" onClick={() => setPage("home")}>
        <h1>FactShare</h1>
        <p className="motto">Verify, Trust, Share</p>
      </div>

      {/* Navigation Links */}
      <div className="nav-links">
        <button onClick={() => setPage("home")}>Home</button>
        <button onClick={() => setPage("community")}>Community</button>
        <button onClick={() => setPage("submit")}>Submit an Article</button>
      </div>
    </nav>
  );
};

export default Navbar;
