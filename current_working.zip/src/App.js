import React, { useState } from "react";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import SubmitArticle from "./pages/SubmitArticle";
import Dashboard from "./pages/Dashboard";
import Community from "./pages/Community"; // ✅ Import Community Page
import Login from "./pages/Login";
import Register from "./pages/Register";
import Chatbot from "./components/Chatbot"; // ✅ Import Chatbot
import "./styles/global.css";

function App() {
  const [page, setPage] = useState("home"); // Handles main navigation
  const [isAuthenticated, setIsAuthenticated] = useState(false); // Tracks login state
  const [authPage, setAuthPage] = useState(null); // Tracks Login/Register page

  return (
    <div>
      {/* Navbar always visible */}
      <Navbar setPage={setPage} />

      {/* Authentication Screens */}
      {authPage === "login" && (
        <Login 
          switchToRegister={() => setAuthPage("register")} 
          onLogin={() => {
            setIsAuthenticated(true);
            setAuthPage(null); // Return to main page after login
          }}
        />
      )}
      {authPage === "register" && (
        <Register 
          switchToLogin={() => setAuthPage("login")} 
          onRegister={() => {
            setIsAuthenticated(true);
            setAuthPage(null); // Return to main page after registration
          }}
        />
      )}

      {/* Main Navigation (Only if NOT in Auth Pages) */}
      {!authPage && (
        <>
          {page === "home" && <Home setAuthPage={setAuthPage} />}
          {page === "submit" && <SubmitArticle />}
          {page === "community" && <Community />} {/* ✅ Show Community Page */}
          {page === "dashboard" && (isAuthenticated ? <Dashboard /> : <Login switchToRegister={() => setAuthPage("register")} />)}
        </>
      )}

      {/* ✅ Persistent Chatbot at Bottom Right */}
      <Chatbot />
    </div>
  );
}

export default App;
