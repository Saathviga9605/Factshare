import React, { useState } from "react";
import "../styles/global.css";

const articles = [
  { 
    title: "AI Revolution: Impact on Jobs", 
    credibility: 85, 
    content: "Artificial Intelligence is reshaping industries, but it also raises concerns about job losses..." 
  },
  { 
    title: "Climate Change: Fact or Fiction?", 
    credibility: 92, 
    content: "Climate change is a scientifically proven phenomenon. Recent studies suggest..." 
  },
  { 
    title: "Electric Vehicles: Are They Sustainable?", 
    credibility: 78, 
    content: "EVs are widely seen as the future of transportation, but challenges remain..." 
  },
];

const Community = () => {
  const [selectedArticle, setSelectedArticle] = useState(null);
  const [votes, setVotes] = useState({}); // Store votes for each article

  const handleVote = (title, type) => {
    setVotes((prevVotes) => {
      const newVotes = { ...prevVotes }; // Create a new copy

      if (!newVotes[title]) {
        newVotes[title] = { upvotes: 0, downvotes: 0, userVote: 0 };
      } else {
        newVotes[title] = { ...newVotes[title] }; // Ensure a new object
      }

      if (type === "up") {
        if (newVotes[title].userVote === 1) {
          newVotes[title].upvotes -= 1;
          newVotes[title].userVote = 0;
        } else {
          if (newVotes[title].userVote === -1) {
            newVotes[title].downvotes -= 1;
          }
          newVotes[title].upvotes += 1;
          newVotes[title].userVote = 1;
        }
      } else {
        if (newVotes[title].userVote === -1) {
          newVotes[title].downvotes -= 1;
          newVotes[title].userVote = 0;
        } else {
          if (newVotes[title].userVote === 1) {
            newVotes[title].upvotes -= 1;
          }
          newVotes[title].downvotes += 1;
          newVotes[title].userVote = -1;
        }
      }
      return newVotes;
    });
  };

  return (
    <div className="community-container">
      <br/>
      <br/>
      <br/>
      <br/>

      {!selectedArticle ? (
        <>
          <h2 className="community-title">APPROVED ARTICLES</h2>
          <p className="community-subtitle">Explore fact-checked articles with credibility scores</p>
          <div className="articles-grid">
            {articles.map((article, index) => (
              <div key={index} className="article-card" onClick={() => setSelectedArticle(article)}>
                <h3 className="article-title">{article.title}</h3>
                <p className="credibility-score">Credibility Score: {article.credibility}%</p>
              </div>
            ))}
          </div>
        </>
      ) : (
        <div className="article-view">
          <button className="back-button" onClick={() => setSelectedArticle(null)}>← Back</button>
          <h2 className="article-title">{selectedArticle.title}</h2>
          <p className="credibility-score">Credibility Score: {selectedArticle.credibility}%</p>
          <p className="article-content">{selectedArticle.content}</p>

          {/* Voting Buttons */}
          <div className="vote-buttons">
            <button 
              className={`vote-btn upvote ${votes[selectedArticle.title]?.userVote === 1 ? "active" : ""}`} 
              onClick={() => handleVote(selectedArticle.title, "up")}
            >
              👍 {votes[selectedArticle.title]?.upvotes || 0}
            </button>

            <button 
              className={`vote-btn downvote ${votes[selectedArticle.title]?.userVote === -1 ? "active" : ""}`} 
              onClick={() => handleVote(selectedArticle.title, "down")}
            >
              👎 {votes[selectedArticle.title]?.downvotes || 0}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Community;